echo "" > run.out
echo "" > run.err
echo "" > run.time
counter=0
cat queries.sql | \
while read CMD; do
echo $CMD
counter=`expr $counter + 1`
date1=$(date +"%s")
echo "running query $counter" >> run.err
beeline -u jdbc:hive2://localhost:10000 -n hive -p hive -e "$CMD" --showHeader=false --force=true --outputformat=csv 1>run.out 2>>run.err
date2=$(date +"%s")
echo "$counter,$date1,$date2,$(($date2-$date1))" >> run.time
done
